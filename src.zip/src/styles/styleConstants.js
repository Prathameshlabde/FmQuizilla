export const fontFamily = 'Helvetica Neue';
export const styleConstants = {
    navFontSize: 17
}

