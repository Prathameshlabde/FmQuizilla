import React, {Component} from 'react';
import {Text, View} from 'react-native';

class Itemss extends Component {
  render() {
    return (
      <View style={{padding: 50}}>
        <Text allowFontScaling={false}>Items</Text>
      </View>
    );
  }
}

export default Itemss;
