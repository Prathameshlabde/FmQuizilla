import React from "react";
import { StatusBar } from "react-native";
export const Statusbar = (
  <StatusBar
    barStyle="light-content"
    hidden={false}
    backgroundColor="#00BCD4"
    translucent={true}
  />
);
