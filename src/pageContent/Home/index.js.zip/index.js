import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {Map} from 'immutable';
import {
  YellowBox,
  Text,
  View,
  TouchableOpacity,
  Platform,
  Alert,
  ActivityIndicator,
} from 'react-native';
import {
  MODULES_ID,
  MODULES_DATA,
  USER_SCORE_ID,
  LAST_SCORE,
  PRACTICE_TEST,
  discountedProducted17Ios,
  productNewIos,
  purchasedNewStr,
  purchaseUserDeafultStr,
  productOldIos,
  purchasedOldStr,
  purchaseAlterTextBoth,
  purchaseAlterTextOld,
  purchaseAlterTextNew,
  purchaseAlterTextNewDiscounted,
  productIosRestoreList,
  productNewAndroid,
  MODULE_AVG_DATA,
  purchaseRestoreNew,
} from '../../constants/app.constants';
import {updateComponentState} from '../../actions/component.actions';
import {StatusBar} from '../StatusBar/statusBar';
import {styles} from '../../styles/styles';
import {getChartModulesData} from './Home.utils';
import {
  getModuleHighScores,
  getModuleList,
  getModuleWiseProgress,
} from '../../components/utils/db.utils';
import FusionChart from '../../components/widgets/FusionChart';
import MiddleView from './MiddleView';
import DefaultPreference from 'react-native-default-preference';

import {
  purchaseProductsIos,
  restoreProductsIos,
} from '../../components/utils/iosInAppPurchase.utils';
import {
  getPracticeTestCount,
  getPracticeTestScore,
} from '../../components/utils/db.utils';
import {Colors} from '../../components/utils/Colors';
import {
  purchaseProductsAndroid,
  restoreProductsAndroid,
} from '../../components/utils/androidInAppPurchase.utils';

import * as Animatable from 'react-native-animatable';

// import RNIap, {
//   Product,
//   ProductPurchase,
//   PurchaseError,
//   acknowledgePurchaseAndroid,
//   purchaseErrorListener,
//   purchaseUpdatedListener,
// } from 'react-native-iap';

class Home extends Component {
  static propTypes = {
    id: PropTypes.string,
    componentState: PropTypes.object.isRequired,
    updateComponentState: PropTypes.func.isRequired,
  };
  constructor(props) {
    super(props);
    this.state = {
      isChartDataReady: false,
      purchasedLatest: true,
      isPracticeTestDisable: false,
      isTrial: true,
      chartData: [],
      showLoader: false,
      purchasedProduct: undefined,
      chartDynamicHeight: 100,
    };

    YellowBox.ignoreWarnings(['requires main queue setup']);
  }

  componentWillMount = () => {
    // purchasedOldStr //purchasedNewStr
    // Addd this line to set usser default for purchased App.
    // DefaultPreference.set(purchaseUserDeafultStr, purchasedNewStr).then(() => {
    //   console.log('Purchased');
    // });

    this._sub = this.props.navigation.addListener(
      'didFocus',
      this._componentFocused,
    );
    this.hideUpgradeButton();
  };
  componentWillUnmount() {
    this._sub.remove();
  }
  componentDidMount() {
    const params = this.props.navigation.state.params;

    if (
      params !== undefined &&
      this.props.navigation.state &&
      params.isFromResultSummary &&
      params.isFromResultSummary === true
    ) {
      this.displayPurchaseAlert();
    }
  }
  _componentFocused = () => {
    this.dbCalls();
    this.getTotaltestAndLastScore();
    this.getModuleProgress();
  };

  getModuleProgress() {
    getModuleWiseProgress().then((response) => {
      const {updateComponentState} = this.props;
      updateComponentState(MODULES_ID, MODULE_AVG_DATA, response);
    });
  }

  find_dimesions(layout) {
    const {height} = layout;
    this.setState({
      chartDynamicHeight: height,
    });
  }

  hideUpgradeButton() {
    DefaultPreference.get(purchaseUserDeafultStr).then((purchasedProduct) => {
      if (purchasedProduct && purchasedProduct === purchasedNewStr) {
        this.setState({
          purchasedLatest: true,
          isPracticeTestDisable: false,
          isTrial: false,
          purchasedProduct,
        });
      } else if (purchasedProduct && purchasedProduct === purchasedOldStr) {
        this.setState({
          purchasedLatest: false,
          isPracticeTestDisable: false,
          isTrial: false,
          purchasedProduct,
        });
      } else {
        this.setState({
          purchasedLatest: false,
          isPracticeTestDisable: true,
          isTrial: true,
          purchasedProduct: undefined,
        });
      }
    });
  }

  dbCalls() {
    let moduleListArr = [];
    let moduleListWithHighScoresArr;

    getModuleList().then((response) => {
      moduleListArr = response;
      const {updateComponentState} = this.props;
      updateComponentState(MODULES_ID, MODULES_DATA, response);
      getModuleHighScores()
        .then((response) => {
          moduleListWithHighScoresArr = response;
          this.setChartData(moduleListArr, moduleListWithHighScoresArr);
        })
        .catch(function () {
          // console.log("Promise Rejected");
        });
    });
  }

  getTotaltestAndLastScore() {
    const {updateComponentState} = this.props;
    getPracticeTestScore().then((response) => {
      updateComponentState(USER_SCORE_ID, LAST_SCORE, response);
    });

    getPracticeTestCount().then((response) => {
      updateComponentState(USER_SCORE_ID, PRACTICE_TEST, response);
    });
  }

  setChartData(moduleListArr, moduleListWithHighScoresArr) {
    let result = getChartModulesData(
      moduleListWithHighScoresArr,
      moduleListArr,
    );
    if (result.length === 0) {
      result = undefined;
    }
    this.setState({
      isChartDataReady: true,
      chartData: result,
    });
  }

  callNewDatabase = () => {
    this.dbCalls();
    this.getTotaltestAndLastScore();
    this.hideUpgradeButton();
    this.stopLoader();
    this.getModuleProgress();
  };

  stopLoader() {
    this.setState({
      showLoader: false,
    });
  }
  startLoader() {
    this.setState(
      {
        showLoader: true,
      },
      () => {
        setTimeout(() => {
          this.stopLoader();
        }, 20000);
      },
    );
  }

  callPurchase(productIdentifier, stringToSet, methodTocallOnSuccess) {
    // handle depending on condition
    let os = Platform.OS;
    if (os === 'android') {
      purchaseProductsAndroid(
        productIdentifier,
        stringToSet,
        methodTocallOnSuccess,
      );
    } else if (os === 'ios') {
      purchaseProductsIos(
        productIdentifier,
        stringToSet,
        methodTocallOnSuccess,
      );
    }
  }

  callRestore(
    callFunctionOnSuccess,
    bundleIdentifier,
    purchaseStr,
    checkDiscount = '',
  ) {
    let os = Platform.OS;
    if (os === 'android') {
      restoreProductsAndroid(
        callFunctionOnSuccess,
        bundleIdentifier,
        purchaseStr,
        checkDiscount,
      );
    } else if (os === 'ios') {
      restoreProductsIos(
        callFunctionOnSuccess,
        bundleIdentifier,
        purchaseStr,
        checkDiscount,
      );
    }
  }

  purchaseProduct(version, discounted = '') {
    let os = Platform.OS;
    if (discounted && discounted !== '') {
      if (os === 'android') {
        ///Discounted android new
      } else {
        this.callPurchase(
          discountedProducted17Ios,
          purchasedNewStr,
          this.callNewDatabase,
        );
      }
    } else {
      if (version === purchaseRestoreNew) {
        if (os === 'android') {
          this.callPurchase(
            productNewAndroid,
            purchasedNewStr,
            this.callNewDatabase,
          );
        } else {
          this.callPurchase(
            productNewIos,
            purchasedNewStr,
            this.callNewDatabase,
          );
        }
      } else {
        if (os === 'android') {
          //Purchase old product
        } else {
          this.callPurchase(
            productOldIos,
            purchasedOldStr,
            this.callNewDatabase,
          );
        }
      }
    }
  }

  restoreProduct(version) {
    let os = Platform.OS;
    if (version === purchaseRestoreNew) {
      if (os === 'android') {
        this.callRestore(
          this.callNewDatabase,
          productNewAndroid,
          purchasedNewStr,
        );
      } else {
        this.callRestore(
          this.callNewDatabase,
          productIosRestoreList,
          purchasedNewStr,
          'checkDiscount',
        );
      }
    } else {
      if (os === 'android') {
        //Restorig old purchase Android
      } else {
        this.callRestore(this.callNewDatabase, productOldIos, purchasedOldStr);
      }
    }
  }

  displayPurchaseAlert() {
    this.startLoader();
    this.displayAlertForNew();

    //IMP Note :- This logic is commented for future use it for handling discount and multiple in-App purchase

    // let os = Platform.OS;
    // if (os === 'android') {
    //   this.displayAlertForNew();
    // } else {
    //   DefaultPreference.get(purchaseUserDeafultStr).then(purchasedProduct => {
    //     if (purchasedProduct && purchasedProduct === purchasedOldStr) {
    //       this.displayAlertForNew('discounted');
    //     } else {
    //       Alert.alert(
    //         purchaseAlterTextBoth.title,
    //         purchaseAlterTextBoth.subtitle,
    //         [
    //           {
    //             text: 'Upgrade to FM 17',
    //             onPress: () => this.displayAlertForNew(),
    //           },
    //           {
    //             text: 'Upgrade to FM 16',
    //             onPress: () => this.displayAlertForOld(),
    //           },
    //           {
    //             text: 'Cancel',
    //             style: 'cancel',
    //             onPress: () => this.stopLoader(),
    //           },
    //         ],
    //         {cancelable: true},
    //       );
    //     }
    //   });
    // }
  }

  displayAlertForOld() {
    Alert.alert(
      purchaseAlterTextOld.title,
      purchaseAlterTextOld.subtitle,
      [
        {text: 'Upgrade to FM 16', onPress: () => this.purchaseProduct(16)},
        {text: 'Restore', onPress: () => this.restoreProduct(16)},
        {
          text: 'Cancel',
          style: 'cancel',
          onPress: () => this.stopLoader(),
        },
      ],
      {cancelable: true},
    );
  }

  displayAlertForNew(discounted) {
    let mainSubtitle = purchaseAlterTextNew.subtitle;
    if (discounted) {
      mainSubtitle = purchaseAlterTextNewDiscounted.subtitle;
    } else {
      mainSubtitle = purchaseAlterTextNew.subtitle;
    }
    Alert.alert(
      purchaseAlterTextNew.title,
      mainSubtitle,
      [
        {
          text: 'Upgrade to FM 19',
          onPress: () => this.purchaseProduct(purchaseRestoreNew, discounted),
        },
        {
          text: 'Restore',
          onPress: () => this.restoreProduct(purchaseRestoreNew),
        },
        {
          text: 'Cancel',
          style: 'cancel',
          onPress: () => this.stopLoader(),
        },
      ],
      {cancelable: true},
    );
  }

  render() {
    const navigation = this.props.navigation;
    const {purchasedLatest, isPracticeTestDisable, isTrial} = this.state;
    let topView = styles.homeTopView;
    let bottomView = styles.homeBottomView;

    if (purchasedLatest === true) {
      topView = [styles.homeTopView, styles.upgradedTopView];
      bottomView = [styles.homeBottomView, styles.upgradedBottomView];
    }

    return (
      <View style={styles.container}>
        {StatusBar}
        {this.state.showLoader === true ? (
          <View style={styles.actiityOverlay}>
            <ActivityIndicator
              animating={this.state.showLoader}
              color={{color: Colors.Black}}
              style={styles.activityIndicator}
            />
          </View>
        ) : null}
        <View style={topView}>
          <Animatable.Text
            allowFontScaling={false}
            animation="bounceIn"
            easing="ease-out"
            iterationCount={1}
            style={styles.paidText}>
            <Text allowFontScaling={false} style={styles.homeAppLogo}>
              FM Quizilla 19
            </Text>
          </Animatable.Text>

          {purchasedLatest === false ? (
            <View style={styles.upgradeButtonView}>
              <TouchableOpacity
                style={styles.upgradeButton}
                activeOpacity={0.9}
                onPress={() => this.displayPurchaseAlert()}>
                <Text allowFontScaling={false} style={styles.upgradeButtonText}>
                  Upgrade
                </Text>
              </TouchableOpacity>
              <View style={styles.largeSeperator} />
            </View>
          ) : null}
        </View>

        <MiddleView
          navigation={navigation}
          isPracticeTestDisable={isPracticeTestDisable}
          isTrial={isTrial}
          purchasedLatest={purchasedLatest}
        />

        <View style={bottomView}>
          <View
            style={styles.chartView}
            onLayout={(event) => {
              this.find_dimesions(event.nativeEvent.layout);
            }}>
            <FusionChart
              chartData={this.state.chartData}
              purchasedProduct={this.state.purchasedProduct}
              chartDynamicHeight={this.state.chartDynamicHeight}
            />
            {/* <ScoreBarChart
              chartData={this.state.chartData}
              purchasedProduct={this.state.purchasedProduct}
              chartDynamicHeight={this.state.chartDynamicHeight}
            /> */}
          </View>
        </View>
      </View>
    );
  }
}

export function mapStateToProps(state, ownProps) {
  const {component} = state;
  // const id = ownProps.id;
  return {
    componentState: component.get(MODULES_ID, Map()),
  };
}

export default connect(mapStateToProps, {
  updateComponentState,
})(Home);
